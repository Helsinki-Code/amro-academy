import { motion } from 'framer-motion';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { NeuralBackground } from '@/components/NeuralBackground';
import { Users, Target, Lightbulb, Heart } from 'lucide-react';

const values = [
  {
    icon: Users,
    title: 'Learner-Centric',
    description: 'Every feature is designed with the learner at the center. Your success is our mission.',
  },
  {
    icon: Target,
    title: 'Innovation First',
    description: 'We push the boundaries of AI and education to create experiences never before possible.',
  },
  {
    icon: Lightbulb,
    title: 'Accessible Knowledge',
    description: 'Everyone deserves quality education. We make AI learning accessible to all.',
  },
  {
    icon: Heart,
    title: 'Community Driven',
    description: 'Our platform thrives because of our amazing community of learners and educators.',
  },
];

const team = [
  { name: 'AI Research', role: 'Pushing Boundaries', emoji: '🔬' },
  { name: 'Voice Tech', role: 'Natural Conversations', emoji: '🎙️' },
  { name: 'Learning Design', role: 'Effective Methods', emoji: '📚' },
  { name: 'UX Excellence', role: 'Delightful Experience', emoji: '✨' },
];

const About = () => {
  return (
    <div className="min-h-screen bg-gradient-hero relative">
      <NeuralBackground />
      <Navigation />
      
      <main className="pt-32 pb-20">
        {/* Hero */}
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-24">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
              About Us
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold mb-6">
              Revolutionizing Education with{' '}
              <span className="text-gradient">Voice AI</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              AMRO AI Academy was founded with a simple belief: learning should be as natural 
              as having a conversation. We're building the future of personalized education 
              through cutting-edge voice AI technology.
            </p>
          </motion.div>
        </section>

        {/* Mission */}
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl sm:text-4xl font-display font-bold mb-6">
                Our <span className="text-gradient">Mission</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                To democratize access to personalized education by creating AI companions 
                that understand, adapt, and grow with each learner. We believe everyone 
                deserves a patient, knowledgeable tutor available 24/7.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Through natural voice conversations, we're breaking down the barriers 
                of traditional education and creating learning experiences that feel 
                human, engaging, and effective.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="glass-card rounded-3xl p-8 text-center"
            >
              <div className="text-6xl mb-4">🎯</div>
              <h3 className="text-2xl font-display font-bold mb-2">Vision 2025</h3>
              <p className="text-muted-foreground">
                1 million learners empowered with AI companions worldwide
              </p>
            </motion.div>
          </div>
        </section>

        {/* Values */}
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-24">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-display font-bold">
              Our <span className="text-gradient">Values</span>
            </h2>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="glass-card rounded-2xl p-6 text-center neural-glow"
              >
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
                  style={{ background: 'var(--gradient-primary)' }}
                >
                  <value.icon size={24} className="text-primary-foreground" />
                </div>
                <h3 className="font-display font-bold mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Team pillars */}
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-display font-bold">
              The <span className="text-gradient">Pillars</span> of AMRO
            </h2>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((pillar, index) => (
              <motion.div
                key={pillar.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -8 }}
                className="glass-card rounded-2xl p-8 text-center"
              >
                <motion.div
                  className="text-5xl mb-4"
                  animate={{ y: [0, -5, 0] }}
                  transition={{ duration: 3, repeat: Infinity, delay: index * 0.3 }}
                >
                  {pillar.emoji}
                </motion.div>
                <h3 className="font-display font-bold mb-1">{pillar.name}</h3>
                <p className="text-sm text-muted-foreground">{pillar.role}</p>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
