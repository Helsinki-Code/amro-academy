import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { NeuralBackground } from '@/components/NeuralBackground';
import { HeroSection } from '@/components/sections/HeroSection';
import { FeaturesSection } from '@/components/sections/FeaturesSection';
import { BadgesSection } from '@/components/sections/BadgesSection';
import { SubjectsSection } from '@/components/sections/SubjectsSection';
import { IntegrationsSection } from '@/components/sections/IntegrationsSection';
import { CTASection } from '@/components/sections/CTASection';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-hero relative">
      <NeuralBackground />
      <Navigation />
      <main>
        <HeroSection />
        <FeaturesSection />
        <SubjectsSection />
        <BadgesSection />
        <IntegrationsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
