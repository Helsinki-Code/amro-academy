import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { NeuralBackground } from '@/components/NeuralBackground';
import { VoiceWave } from '@/components/VoiceWave';
import { Search, Filter, Mic, Star, Clock, Users } from 'lucide-react';

const subjects = [
  'All', 'Agentic AI', 'Machine Learning', 'Data Science', 'Neural Networks', 
  'Python', 'NLP', 'Computer Vision', 'Deep Learning'
];

const companions = [
  {
    id: 1,
    name: 'Alex - AI Fundamentals',
    subject: 'Agentic AI',
    description: 'Master the fundamentals of Agentic AI with step-by-step guidance.',
    rating: 4.9,
    sessions: 1240,
    emoji: '🤖',
  },
  {
    id: 2,
    name: 'Nova - ML Expert',
    subject: 'Machine Learning',
    description: 'Deep dive into machine learning algorithms and implementations.',
    rating: 4.8,
    sessions: 980,
    emoji: '🧠',
  },
  {
    id: 3,
    name: 'Data Guide',
    subject: 'Data Science',
    description: 'Learn data analysis, visualization, and statistical methods.',
    rating: 4.9,
    sessions: 1560,
    emoji: '📊',
  },
  {
    id: 4,
    name: 'Neural Master',
    subject: 'Neural Networks',
    description: 'Understand neural network architectures from basics to advanced.',
    rating: 4.7,
    sessions: 720,
    emoji: '🕸️',
  },
  {
    id: 5,
    name: 'Python Pro',
    subject: 'Python',
    description: 'Master Python programming for AI and data science applications.',
    rating: 4.9,
    sessions: 2100,
    emoji: '🐍',
  },
  {
    id: 6,
    name: 'NLP Specialist',
    subject: 'NLP',
    description: 'Explore natural language processing and text analysis.',
    rating: 4.8,
    sessions: 640,
    emoji: '💬',
  },
];

const Companions = () => {
  const [activeSubject, setActiveSubject] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCompanions = companions.filter(companion => {
    const matchesSubject = activeSubject === 'All' || companion.subject === activeSubject;
    const matchesSearch = companion.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         companion.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-hero relative">
      <NeuralBackground />
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
              AI Companions Library
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold mb-6">
              Find Your Perfect <span className="text-gradient">Learning Partner</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Browse our collection of AI companions specialized in various domains
            </p>
          </motion.div>

          {/* Search & Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="mb-12"
          >
            {/* Search bar */}
            <div className="relative max-w-xl mx-auto mb-8">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
              <input
                type="text"
                placeholder="Search companions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-2xl glass-card border-0 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>

            {/* Subject filters */}
            <div className="flex flex-wrap justify-center gap-2">
              {subjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => setActiveSubject(subject)}
                  className={`px-4 py-2 rounded-xl font-medium text-sm transition-all duration-300 ${
                    activeSubject === subject
                      ? 'btn-premium text-primary-foreground'
                      : 'glass-card hover:bg-primary/10'
                  }`}
                >
                  {subject}
                </button>
              ))}
            </div>
          </motion.div>

          {/* Companions grid */}
          <motion.div
            layout
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredCompanions.map((companion, index) => (
                <motion.div
                  key={companion.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                  whileHover={{ y: -8 }}
                  className="glass-card rounded-2xl p-6 neural-glow cursor-pointer group"
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <motion.div
                      className="text-4xl"
                      animate={{ rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 4, repeat: Infinity }}
                    >
                      {companion.emoji}
                    </motion.div>
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                      {companion.subject}
                    </span>
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-display font-bold mb-2">{companion.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    {companion.description}
                  </p>

                  {/* Stats */}
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-amber-500" />
                      <span>{companion.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users size={14} />
                      <span>{companion.sessions} sessions</span>
                    </div>
                  </div>

                  {/* Action */}
                  <button className="w-full btn-outline-premium py-3 rounded-xl flex items-center justify-center gap-2 group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                    <Mic size={16} />
                    <span>Start Learning</span>
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredCompanions.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-display font-bold mb-2">No companions found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filter</p>
            </motion.div>
          )}

          {/* Create own CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 text-center"
          >
            <div className="glass-card rounded-2xl p-8 inline-block">
              <h3 className="text-xl font-display font-bold mb-2">
                Can't find what you're looking for?
              </h3>
              <p className="text-muted-foreground mb-4">
                Create your own custom AI companion tailored to your needs
              </p>
              <button className="btn-premium px-6 py-3 rounded-xl text-primary-foreground font-medium">
                Create Companion
              </button>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Companions;
