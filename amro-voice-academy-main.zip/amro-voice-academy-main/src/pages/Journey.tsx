import { motion } from 'framer-motion';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { NeuralBackground } from '@/components/NeuralBackground';
import { BookOpen, Clock, Award, TrendingUp } from 'lucide-react';

const stats = [
  { icon: BookOpen, label: 'Sessions Completed', value: '42', color: 'from-blue-400 to-blue-600' },
  { icon: Clock, label: 'Hours Learned', value: '28', color: 'from-emerald-400 to-emerald-600' },
  { icon: Award, label: 'Badges Earned', value: '5', color: 'from-amber-400 to-amber-600' },
  { icon: TrendingUp, label: 'Current Streak', value: '7 days', color: 'from-rose-400 to-rose-600' },
];

const badges = [
  { name: 'Student', emoji: '🎒', earned: true },
  { name: 'Mentor', emoji: '🧑‍🏫', earned: true },
  { name: 'Graduate', emoji: '🎓', earned: false },
  { name: 'Top Performer', emoji: '🏆', earned: false },
];

const recentSessions = [
  { companion: 'Alex - AI Fundamentals', subject: 'Agentic AI', date: 'Today', duration: '25 min' },
  { companion: 'Nova - ML Expert', subject: 'Machine Learning', date: 'Yesterday', duration: '40 min' },
  { companion: 'Python Pro', subject: 'Python', date: '2 days ago', duration: '35 min' },
];

const Journey = () => {
  return (
    <div className="min-h-screen bg-gradient-hero relative">
      <NeuralBackground />
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <div className="glass-card rounded-3xl p-8 sm:p-12 flex flex-col sm:flex-row items-center gap-8">
              {/* Avatar */}
              <motion.div
                className="w-28 h-28 rounded-2xl flex items-center justify-center text-5xl"
                style={{ background: 'var(--gradient-primary)' }}
                whileHover={{ scale: 1.05 }}
              >
                👨‍🎓
              </motion.div>
              
              <div className="text-center sm:text-left flex-1">
                <h1 className="text-3xl sm:text-4xl font-display font-bold mb-2">
                  Welcome back, <span className="text-gradient">Learner</span>
                </h1>
                <p className="text-muted-foreground text-lg">
                  Your learning journey continues. Keep up the great work!
                </p>
              </div>

              {/* Level indicator */}
              <div className="text-center">
                <div className="text-4xl font-display font-bold text-gradient">Level 8</div>
                <div className="text-sm text-muted-foreground">Advanced Learner</div>
                <div className="mt-2 h-2 w-32 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: 'var(--gradient-primary)' }}
                    initial={{ width: 0 }}
                    animate={{ width: '75%' }}
                    transition={{ duration: 1, delay: 0.5 }}
                  />
                </div>
                <div className="text-xs text-muted-foreground mt-1">75% to Level 9</div>
              </div>
            </div>
          </motion.div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="glass-card rounded-2xl p-6 text-center neural-glow"
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 bg-gradient-to-br ${stat.color}`}>
                  <stat.icon size={24} className="text-white" />
                </div>
                <div className="text-2xl font-display font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Badges */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="glass-card rounded-2xl p-6"
            >
              <h2 className="text-xl font-display font-bold mb-6">Your Badges</h2>
              <div className="grid grid-cols-2 gap-4">
                {badges.map((badge, index) => (
                  <motion.div
                    key={badge.name}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.4 }}
                    className={`p-4 rounded-xl text-center ${
                      badge.earned ? 'bg-primary/10' : 'bg-muted/50 opacity-50'
                    }`}
                  >
                    <motion.div
                      className={`text-3xl mb-2 ${badge.earned ? 'badge-glow' : 'grayscale'}`}
                      animate={badge.earned ? { scale: [1, 1.1, 1] } : {}}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      {badge.emoji}
                    </motion.div>
                    <div className="font-display font-semibold text-sm">{badge.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {badge.earned ? 'Earned' : 'Locked'}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Recent sessions */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="glass-card rounded-2xl p-6"
            >
              <h2 className="text-xl font-display font-bold mb-6">Recent Sessions</h2>
              <div className="space-y-4">
                {recentSessions.map((session, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.4 }}
                    className="flex items-center gap-4 p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center text-lg"
                      style={{ background: 'var(--gradient-primary)' }}
                    >
                      🎙️
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-display font-semibold text-sm truncate">
                        {session.companion}
                      </div>
                      <div className="text-xs text-muted-foreground">{session.subject}</div>
                    </div>
                    <div className="text-right text-sm">
                      <div className="text-muted-foreground">{session.date}</div>
                      <div className="text-primary font-medium">{session.duration}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Certificates CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-12"
          >
            <div className="glass-card rounded-2xl p-8 text-center">
              <div className="text-4xl mb-4">📜</div>
              <h3 className="text-xl font-display font-bold mb-2">Your Certificates</h3>
              <p className="text-muted-foreground mb-4">
                Complete more courses to earn verifiable certificates
              </p>
              <div className="flex justify-center gap-4 opacity-50">
                <div className="w-32 h-20 rounded-lg border-2 border-dashed border-border flex items-center justify-center text-sm text-muted-foreground">
                  Coming soon
                </div>
                <div className="w-32 h-20 rounded-lg border-2 border-dashed border-border flex items-center justify-center text-sm text-muted-foreground">
                  Coming soon
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Journey;
