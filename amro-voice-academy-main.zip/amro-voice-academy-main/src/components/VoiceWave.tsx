import { motion } from 'framer-motion';

interface VoiceWaveProps {
  isActive?: boolean;
  className?: string;
}

export function VoiceWave({ isActive = true, className = '' }: VoiceWaveProps) {
  const bars = 5;
  const delays = [0, 0.1, 0.2, 0.1, 0];

  return (
    <div className={`flex items-center justify-center gap-1 h-8 ${className}`}>
      {Array.from({ length: bars }).map((_, i) => (
        <motion.div
          key={i}
          className="voice-wave-bar w-1 origin-center"
          animate={isActive ? {
            scaleY: [0.3, 1, 0.3],
            opacity: [0.6, 1, 0.6],
          } : {
            scaleY: 0.3,
            opacity: 0.4,
          }}
          transition={{
            duration: 0.6,
            repeat: isActive ? Infinity : 0,
            delay: delays[i],
            ease: 'easeInOut',
          }}
          style={{ height: '100%' }}
        />
      ))}
    </div>
  );
}

interface VoiceWaveLargeProps {
  className?: string;
}

export function VoiceWaveLarge({ className = '' }: VoiceWaveLargeProps) {
  const bars = 12;

  return (
    <div className={`flex items-center justify-center gap-1.5 h-16 ${className}`}>
      {Array.from({ length: bars }).map((_, i) => {
        const delay = Math.sin((i / bars) * Math.PI) * 0.3;
        const height = 20 + Math.sin((i / bars) * Math.PI) * 30;
        
        return (
          <motion.div
            key={i}
            className="voice-wave-bar w-1.5 rounded-full origin-center"
            style={{ height: `${height}%` }}
            animate={{
              scaleY: [0.4, 1, 0.4],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 0.8 + Math.random() * 0.4,
              repeat: Infinity,
              delay: delay,
              ease: 'easeInOut',
            }}
          />
        );
      })}
    </div>
  );
}
