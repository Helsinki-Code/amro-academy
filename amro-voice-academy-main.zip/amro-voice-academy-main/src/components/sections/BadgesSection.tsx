import { motion } from 'framer-motion';

const badges = [
  {
    name: 'Student',
    requirement: 'Account Creation',
    description: 'Awarded to all new learners',
    emoji: '🎒',
    gradient: 'from-blue-400 to-blue-600',
  },
  {
    name: 'Mentor',
    requirement: '5+ Companions',
    description: 'Create 5+ learning companions',
    emoji: '🧑‍🏫',
    gradient: 'from-emerald-400 to-emerald-600',
  },
  {
    name: 'Instructor',
    requirement: '10+ Companions & 20+ Sessions',
    description: 'Advanced recognition for dedication',
    emoji: '👨‍🎓',
    gradient: 'from-purple-400 to-purple-600',
  },
  {
    name: 'Graduate',
    requirement: 'Complete Milestones',
    description: 'Significant learning achievements',
    emoji: '🎓',
    gradient: 'from-amber-400 to-amber-600',
  },
  {
    name: 'Top Performer',
    requirement: 'Excellence Criteria',
    description: 'Outstanding performance recognition',
    emoji: '🏆',
    gradient: 'from-rose-400 to-rose-600',
  },
];

const certificates = [
  {
    name: 'Course Completion',
    description: 'Earned upon completing courses',
    type: 'completion',
  },
  {
    name: 'Top Performer',
    description: 'Recognition for exceptional performance',
    type: 'excellence',
  },
];

export function BadgesSection() {
  return (
    <section className="py-24 sm:py-32 relative">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16 sm:mb-20"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
            Achievement System
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold">
            Earn <span className="text-gradient">Badges</span> & Certificates
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Your learning journey is rewarded with achievements that showcase your 
            dedication and expertise.
          </p>
          <div className="section-divider mt-8" />
        </motion.div>

        {/* Badges */}
        <div className="mb-20">
          <h3 className="text-2xl font-display font-bold text-center mb-10">Badge Collection</h3>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="flex flex-wrap justify-center gap-6 lg:gap-10"
          >
            {badges.map((badge, index) => (
              <motion.div
                key={badge.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="glass-card rounded-2xl p-6 w-40 text-center group cursor-pointer"
              >
                <motion.div
                  className="text-5xl mb-4 badge-glow inline-block"
                  animate={{ rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 4, repeat: Infinity, delay: index * 0.2 }}
                >
                  {badge.emoji}
                </motion.div>
                <h4 className="font-display font-bold text-sm mb-1">{badge.name}</h4>
                <p className="text-xs text-muted-foreground">{badge.requirement}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Certificates */}
        <div>
          <h3 className="text-2xl font-display font-bold text-center mb-10">Certificates</h3>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {certificates.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, x: index === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                whileHover={{ scale: 1.02 }}
                className="glass-card rounded-2xl p-8 relative overflow-hidden group"
              >
                {/* Decorative border */}
                <div className="absolute inset-2 border-2 border-dashed border-primary/20 rounded-xl pointer-events-none" />
                
                {/* Certificate content */}
                <div className="relative text-center py-6">
                  <div className="text-4xl mb-4">📜</div>
                  <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">
                    Certificate of
                  </div>
                  <h4 className="text-xl font-display font-bold text-gradient mb-2">
                    {cert.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">{cert.description}</p>
                  
                  {/* Stamp effect */}
                  <div className="absolute top-4 right-4 w-16 h-16 rounded-full border-2 border-primary/30 flex items-center justify-center rotate-12 opacity-50 group-hover:opacity-100 transition-opacity">
                    <span className="text-xs font-display font-bold text-primary text-center leading-tight">
                      AMRO<br/>AI
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
