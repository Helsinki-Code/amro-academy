import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { VoiceWave } from '@/components/VoiceWave';

export function CTASection() {
  return (
    <section className="py-24 sm:py-32 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-30"
          style={{ background: 'var(--gradient-primary)', filter: 'blur(120px)' }}
          animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass-card rounded-3xl p-8 sm:p-12 lg:p-16 text-center"
        >
          {/* Voice wave decoration */}
          <div className="flex justify-center mb-8">
            <div className="p-4 rounded-full" style={{ background: 'var(--gradient-primary)' }}>
              <VoiceWave isActive className="scale-150" />
            </div>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold mb-6">
            Ready to Transform Your{' '}
            <span className="text-gradient">Learning Journey</span>?
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Join thousands of learners who have discovered the power of voice-first 
            AI education. Start your personalized learning experience today.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/companions"
              className="btn-premium px-10 py-5 rounded-2xl text-primary-foreground font-display font-semibold text-lg flex items-center justify-center gap-2 group"
            >
              <span className="relative z-10">Get Started Free</span>
              <ArrowRight size={20} className="relative z-10 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/about"
              className="btn-outline-premium px-10 py-5 rounded-2xl font-display font-semibold text-lg"
            >
              Learn More
            </Link>
          </div>

          {/* Trust indicators */}
          <div className="mt-12 pt-8 border-t border-border">
            <p className="text-sm text-muted-foreground mb-4">Trusted by learners worldwide</p>
            <div className="flex justify-center items-center gap-8 opacity-60">
              {['🏛️ Universities', '🏢 Enterprises', '🌍 Global Community'].map((item, i) => (
                <motion.span
                  key={i}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="text-sm font-medium"
                >
                  {item}
                </motion.span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
