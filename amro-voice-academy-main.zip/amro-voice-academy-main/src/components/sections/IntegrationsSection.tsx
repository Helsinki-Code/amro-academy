import { motion } from 'framer-motion';

const integrations = [
  { name: 'Vapi', description: 'Voice AI', icon: '🎙️' },
  { name: 'Supabase', description: 'Backend', icon: '⚡' },
  { name: 'Clerk', description: 'Auth', icon: '🔐' },
  { name: 'React', description: 'Frontend', icon: '⚛️' },
];

export function IntegrationsSection() {
  return (
    <section className="py-24 sm:py-32 relative">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
            Technology Stack
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold">
            Powered by <span className="text-gradient">Best-in-Class</span> Tech
          </h2>
          <p className="mt-6 text-lg text-muted-foreground">
            Built on a foundation of cutting-edge technologies for reliability and performance.
          </p>
        </motion.div>

        {/* Integration nodes with connections */}
        <div className="relative max-w-3xl mx-auto">
          {/* Connection lines SVG */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 200">
            <motion.line
              x1="100" y1="100" x2="200" y2="100"
              stroke="var(--neural-line)"
              strokeWidth="2"
              strokeDasharray="5 5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: 0.5 }}
            />
            <motion.line
              x1="200" y1="100" x2="300" y2="100"
              stroke="var(--neural-line)"
              strokeWidth="2"
              strokeDasharray="5 5"
              initial={{ pathLength: 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: 0.7 }}
            />
          </svg>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {integrations.map((integration, index) => (
              <motion.div
                key={integration.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15, duration: 0.6 }}
                whileHover={{ y: -8, scale: 1.05 }}
                className="glass-card rounded-2xl p-6 text-center neural-glow cursor-pointer"
              >
                <motion.div
                  className="text-4xl mb-4"
                  animate={{ y: [0, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                >
                  {integration.icon}
                </motion.div>
                <h3 className="font-display font-bold">{integration.name}</h3>
                <p className="text-sm text-muted-foreground">{integration.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
