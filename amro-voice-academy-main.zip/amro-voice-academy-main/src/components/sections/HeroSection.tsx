import { motion } from 'framer-motion';
import { ArrowRight, Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { VoiceWaveLarge } from '../VoiceWave';
import amroLogo from '@/assets/amro-logo.png';

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
      {/* Floating decorative elements */}
      <motion.div
        className="absolute top-1/4 left-10 w-64 h-64 rounded-full opacity-30"
        style={{ background: 'var(--gradient-primary)', filter: 'blur(80px)' }}
        animate={{ y: [0, -30, 0], x: [0, 15, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-1/4 right-10 w-96 h-96 rounded-full opacity-20"
        style={{ background: 'var(--gradient-primary)', filter: 'blur(100px)' }}
        animate={{ y: [0, 20, 0], x: [0, -20, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8"
            >
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-sm font-medium text-muted-foreground">
                Voice-First AI Learning Platform
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-display font-bold leading-tight"
            >
              Learn Through{' '}
              <span className="text-gradient">Voice</span>
              <br />
              <span className="text-muted-foreground">With AI Companions</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-xl mx-auto lg:mx-0 leading-relaxed"
            >
              Experience personalized education through natural voice conversations 
              with AI tutors that adapt to your unique learning style.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Link
                to="/companions"
                className="btn-premium px-8 py-4 rounded-2xl text-primary-foreground font-display font-semibold flex items-center justify-center gap-2 group"
              >
                <span className="relative z-10">Start Learning</span>
                <ArrowRight size={18} className="relative z-10 group-hover:translate-x-1 transition-transform" />
              </Link>
              <button className="btn-outline-premium px-8 py-4 rounded-2xl flex items-center justify-center gap-2">
                <Play size={18} />
                <span>Watch Demo</span>
              </button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-16 grid grid-cols-3 gap-8"
            >
              {[
                { value: '50K+', label: 'Active Learners' },
                { value: '200+', label: 'AI Companions' },
                { value: '98%', label: 'Satisfaction' },
              ].map((stat, i) => (
                <div key={i} className="text-center lg:text-left">
                  <div className="text-2xl sm:text-3xl font-display font-bold text-gradient">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative"
          >
            {/* Main card */}
            <div className="relative glass-card rounded-3xl p-8 sm:p-12">
              {/* Voice wave visualization */}
              <div className="flex justify-center mb-8">
                <motion.div
                  className="w-32 h-32 rounded-full flex items-center justify-center relative"
                  style={{ background: 'var(--gradient-primary)' }}
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <div className="absolute inset-0 rounded-full animate-pulse-glow" />
                  <img src={amroLogo} alt="AI" className="w-20 h-20 object-contain relative z-10" />
                </motion.div>
              </div>

              {/* Voice wave */}
              <VoiceWaveLarge className="mb-8" />

              {/* Simulated conversation */}
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-muted px-4 py-3 rounded-2xl rounded-bl-md max-w-[80%]">
                    <p className="text-sm">Explain neural networks in simple terms.</p>
                  </div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.5 }}
                  className="flex justify-end"
                >
                  <div className="px-4 py-3 rounded-2xl rounded-br-md max-w-[80%]" style={{ background: 'var(--gradient-primary)' }}>
                    <p className="text-sm text-primary-foreground">
                      Think of neural networks like a brain made of tiny decision-makers...
                    </p>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Floating badge cards */}
            <motion.div
              className="absolute -top-6 -left-6 glass-card px-4 py-3 rounded-xl"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎓</span>
                <span className="font-display font-semibold text-sm">+15 Badges Earned</span>
              </div>
            </motion.div>
            <motion.div
              className="absolute -bottom-4 -right-4 glass-card px-4 py-3 rounded-xl"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity }}
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl">🏆</span>
                <span className="font-display font-semibold text-sm">Top Performer</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
