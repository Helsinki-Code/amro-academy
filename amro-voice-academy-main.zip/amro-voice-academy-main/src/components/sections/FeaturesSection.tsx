import { motion } from 'framer-motion';
import { Bot, Mic, Brain, Sparkles, Zap, Target } from 'lucide-react';

const features = [
  {
    icon: Bot,
    title: 'AI Voice Companions',
    description: 'Create custom AI tutors that specialize in any subject and engage through natural voice conversations.',
  },
  {
    icon: Brain,
    title: 'Adaptive Learning',
    description: 'AI that understands your learning style and adapts explanations to match your comprehension level.',
  },
  {
    icon: Mic,
    title: 'Voice-First Experience',
    description: 'Learn through natural conversations instead of reading. Just speak and your AI companion responds.',
  },
  {
    icon: Sparkles,
    title: 'Multi-Domain Expertise',
    description: 'From Agentic AI to Neural Networks, access specialized knowledge across cutting-edge technologies.',
  },
  {
    icon: Zap,
    title: 'Real-Time Sessions',
    description: 'Low-latency voice interactions that feel like talking to a real tutor, powered by Vapi.',
  },
  {
    icon: Target,
    title: 'Progress Tracking',
    description: 'Earn badges, certificates, and track your journey from student to expert with detailed analytics.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

export function FeaturesSection() {
  return (
    <section className="py-24 sm:py-32 relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-neural opacity-50" />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16 sm:mb-20"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
            Platform Features
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold">
            Everything You Need to{' '}
            <span className="text-gradient">Master AI</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            A comprehensive learning platform that combines cutting-edge AI technology 
            with proven educational methodologies.
          </p>
          <div className="section-divider mt-8" />
        </motion.div>

        {/* Features grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8"
        >
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="group glass-card rounded-2xl p-8 neural-glow"
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform duration-500 group-hover:scale-110"
                style={{ background: 'var(--gradient-primary)' }}
              >
                <feature.icon size={24} className="text-primary-foreground" />
              </div>
              <h3 className="text-xl font-display font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
