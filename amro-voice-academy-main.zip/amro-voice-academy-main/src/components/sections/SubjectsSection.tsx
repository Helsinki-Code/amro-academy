import { motion } from 'framer-motion';

const subjects = [
  { name: 'Agentic AI', icon: '🤖', color: 'hsl(186 100% 50%)' },
  { name: 'Machine Learning', icon: '🧠', color: 'hsl(200 80% 50%)' },
  { name: 'Data Science', icon: '📊', color: 'hsl(160 70% 45%)' },
  { name: 'Neural Networks', icon: '🕸️', color: 'hsl(280 70% 55%)' },
  { name: 'Python', icon: '🐍', color: 'hsl(45 90% 50%)' },
  { name: 'NLP', icon: '💬', color: 'hsl(340 75% 55%)' },
  { name: 'Computer Vision', icon: '👁️', color: 'hsl(210 80% 55%)' },
  { name: 'Deep Learning', icon: '⚡', color: 'hsl(35 95% 55%)' },
];

export function SubjectsSection() {
  return (
    <section className="py-24 sm:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-neural opacity-30" />
      
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-6">
            Learning Domains
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold">
            Master <span className="text-gradient">Any Subject</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground">
            AI companions specialized in cutting-edge technologies and methodologies.
          </p>
        </motion.div>

        {/* Scrolling subjects */}
        <div className="relative">
          {/* Fade edges */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
          
          <motion.div
            className="flex gap-6 py-4"
            animate={{ x: [0, -50 * subjects.length] }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          >
            {[...subjects, ...subjects, ...subjects].map((subject, index) => (
              <motion.div
                key={`${subject.name}-${index}`}
                whileHover={{ scale: 1.1, y: -5 }}
                className="flex-shrink-0 glass-card px-6 py-4 rounded-2xl flex items-center gap-3 cursor-pointer neural-glow"
              >
                <span className="text-2xl">{subject.icon}</span>
                <span className="font-display font-semibold whitespace-nowrap">{subject.name}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-center mt-12"
        >
          <p className="text-muted-foreground">
            And many more subjects available. Create your own specialized companion!
          </p>
        </motion.div>
      </div>
    </section>
  );
}
