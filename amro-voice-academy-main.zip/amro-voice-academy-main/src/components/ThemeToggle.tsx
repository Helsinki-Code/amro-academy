import { motion } from 'framer-motion';
import { useTheme } from '@/context/ThemeContext';

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <motion.button
      onClick={toggleTheme}
      className="relative w-20 h-10 rounded-full p-1 transition-colors duration-500"
      style={{
        background: isDark 
          ? 'linear-gradient(135deg, hsl(220 40% 12%), hsl(220 35% 18%))' 
          : 'linear-gradient(135deg, hsl(200 80% 90%), hsl(186 60% 85%))',
        boxShadow: isDark 
          ? 'inset 0 2px 8px hsl(0 0% 0% / 0.3), 0 0 20px hsl(186 100% 50% / 0.2)' 
          : 'inset 0 2px 8px hsl(200 50% 70% / 0.3), 0 4px 12px hsl(186 100% 50% / 0.15)',
      }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      aria-label={`Switch to ${isDark ? 'light' : 'dark'} mode`}
    >
      {/* Neural connection lines */}
      <svg className="absolute inset-0 w-full h-full overflow-visible" viewBox="0 0 80 40">
        <motion.line
          x1="15"
          y1="20"
          x2="65"
          y2="20"
          stroke={isDark ? 'hsl(186 100% 50% / 0.3)' : 'hsl(200 60% 50% / 0.2)'}
          strokeWidth="1"
          strokeDasharray="4 2"
          animate={{ strokeDashoffset: isDark ? [0, 12] : [12, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        />
        <motion.line
          x1="15"
          y1="12"
          x2="65"
          y2="28"
          stroke={isDark ? 'hsl(186 100% 50% / 0.2)' : 'hsl(200 60% 50% / 0.15)'}
          strokeWidth="0.5"
          strokeDasharray="3 3"
          animate={{ strokeDashoffset: isDark ? [0, 12] : [12, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        />
        <motion.line
          x1="15"
          y1="28"
          x2="65"
          y2="12"
          stroke={isDark ? 'hsl(186 100% 50% / 0.2)' : 'hsl(200 60% 50% / 0.15)'}
          strokeWidth="0.5"
          strokeDasharray="3 3"
          animate={{ strokeDashoffset: isDark ? [12, 0] : [0, 12] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        />
      </svg>

      {/* Toggle knob */}
      <motion.div
        className="relative w-8 h-8 rounded-full flex items-center justify-center"
        style={{
          background: isDark 
            ? 'linear-gradient(135deg, hsl(186 100% 50%), hsl(200 100% 45%))' 
            : 'linear-gradient(135deg, hsl(40 100% 70%), hsl(35 100% 60%))',
          boxShadow: isDark 
            ? '0 0 20px hsl(186 100% 50% / 0.6), inset 0 1px 2px hsl(0 0% 100% / 0.2)' 
            : '0 0 15px hsl(40 100% 60% / 0.5), inset 0 1px 2px hsl(0 0% 100% / 0.3)',
        }}
        animate={{ x: isDark ? 40 : 0 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
      >
        {/* Icon */}
        <motion.div
          animate={{ rotate: isDark ? 360 : 0, scale: [1, 1.1, 1] }}
          transition={{ rotate: { duration: 0.5 }, scale: { duration: 0.3 } }}
        >
          {isDark ? (
            // Moon with stars
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <motion.path
                d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
                fill="hsl(220 40% 10%)"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.5 }}
              />
              <motion.circle
                cx="19"
                cy="5"
                r="1"
                fill="hsl(186 100% 80%)"
                animate={{ opacity: [0.5, 1, 0.5], scale: [0.8, 1, 0.8] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.circle
                cx="16"
                cy="8"
                r="0.5"
                fill="hsl(186 100% 80%)"
                animate={{ opacity: [0.3, 0.8, 0.3], scale: [0.9, 1.1, 0.9] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
              />
            </svg>
          ) : (
            // Sun with rays
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <motion.circle
                cx="12"
                cy="12"
                r="4"
                fill="hsl(0 0% 100%)"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
                <motion.line
                  key={angle}
                  x1={12 + 6 * Math.cos((angle * Math.PI) / 180)}
                  y1={12 + 6 * Math.sin((angle * Math.PI) / 180)}
                  x2={12 + 9 * Math.cos((angle * Math.PI) / 180)}
                  y2={12 + 9 * Math.sin((angle * Math.PI) / 180)}
                  stroke="hsl(0 0% 100%)"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  animate={{ opacity: [0.6, 1, 0.6] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
                />
              ))}
            </svg>
          )}
        </motion.div>
      </motion.div>

      {/* Neural nodes */}
      <motion.div
        className="absolute left-2 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full"
        style={{
          background: isDark ? 'hsl(186 100% 50% / 0.5)' : 'hsl(200 60% 50% / 0.4)',
        }}
        animate={{ scale: isDark ? [1, 1.3, 1] : [1.3, 1, 1.3] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
      <motion.div
        className="absolute right-2 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full"
        style={{
          background: isDark ? 'hsl(186 100% 50% / 0.8)' : 'hsl(200 60% 50% / 0.3)',
        }}
        animate={{ scale: isDark ? [1.3, 1, 1.3] : [1, 1.3, 1] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
    </motion.button>
  );
}
